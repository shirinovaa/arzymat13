package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        //write your code here

        String helloWorld;
        final int NUM = 16;
        String word = " Hello";
        helloWorld = NUM + word;
        System.out.println(helloWorld);

        if (NUM < 0) {
            System.out.println("Вы сохронили отрицательное число");
        } else if (NUM > 0) {
            System.out.println("Вы сохронили положительное число");
        } else {
            System.out.println("Вы сохронили нуль");

        }
    }
}
